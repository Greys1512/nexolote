﻿# HU-01: Inicialización del proyecto NEXOLOTE (Monorepo + Git)

## Objetivo
Configurar estructura monorepo, inicializar repositorio Git y dejar listo para desarrollo Frontend/Backend.

## Stack
- Frontend: React + TypeScript + Vite (apps/web)
- Backend: Node.js + NestJS (apps/api)
- BD: PostgreSQL + pg (sin ORM)
- Docs: Swagger
- VCS: Git + GitHub

## Arquitectura
Monorepo con pps/, db/, docs/. Separación clara Frontend/Backend.

## PASO A PASO DETALLADO

### PARTE A: ESTRUCTURA FRONTEND/BACKEND
Crear carpetas:
`ash
mkdir -p nexolote/apps/web nexolote/apps/api nexolote/db nexolote/docs/modelo nexolote/docs/api
cd nexolote
`

### PARTE B: INICIALIZAR GIT
`ash
git init
git branch -M main
`

Crear .gitignore en raíz con node_modules, dist, .env, coverage, logs.

### PARTE C: PREPARAR FRONTEND (sin instalar aún)
Ubicación: pps/web/ - Se inicializará en HU-10. Solo crear estructura vacía si se desea.

### PARTE D: PREPARAR BACKEND (sin instalar aún)
Ubicación: pps/api/ - Se inicializará en HU-03.

## COMANDOS PARA MONTAR A GIT
`ash
git add .
git commit -m "chore(HU-01): inicializa monorepo NEXOLOTE con estructura apps/db/docs"
git remote add origin <URL_GITHUB>
git push -u origin main
`

## CRITERIOS DE ACEPTACIÓN
- [ ] Monorepo creado con apps/web, apps/api, db, docs
- [ ] .gitignore correcto
- [ ] Repositorio Git inicializado
- [ ] Commit inicial realizado

## ENTREGABLES
- Estructura base
- .gitignore
- README.md inicial
