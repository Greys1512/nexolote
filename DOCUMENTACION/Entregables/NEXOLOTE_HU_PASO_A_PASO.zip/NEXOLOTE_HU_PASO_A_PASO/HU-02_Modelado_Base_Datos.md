﻿# HU-02: Diseño, Modelado y Esquema de Base de Datos

## Objetivo
Diseñar modelo relacional normalizado, crear esquema SQL y documentar.

## Alcance
Solo Base de Datos / Documentación.

## Entidades
Producto, Proveedor, MateriaPrima, LoteMateriaPrima, LoteProduccion, ConsumoMateriaPrima, Equipo, Responsable, Mantenimiento, UsoEquipoLote, Ubicacion, MovimientoLote, Incidencia

## Pasos
### 1. Crear esquema
Archivo: db/schema.sql con tablas, PK, FK, UNIQUE, CHECK

### 2. Tablas asociativas N:M
- consumo_materia_prima (PK compuesta id_lote, id_lote_mp)
- uso_equipo_lote (PK compuesta id_lote, id_equipo)

### 3. Reglas de integridad
- Cantidades > 0
- Códigos únicos
- FK obligatorias según modelo
- Incidencia.id_responsable NULL permitido
- MovimientoLote: origen/destino NULL según ingreso/traslado/salida

### 4. Documentación
Crear en docs/modelo/: diccionario-datos.md, DER_NEXOLOTE.png, normalizacion.md

## Comandos
`ash
psql -U postgres -c "CREATE DATABASE nexolote;"
psql -U postgres -d nexolote -f db/schema.sql
`",
  ",
  
- db/schema.sql
- docs/modelo/*

## Criterios de aceptación
- [ ] Tablas y relaciones correctas
- [ ] Restricciones aplicadas
- [ ] Documentación completa
