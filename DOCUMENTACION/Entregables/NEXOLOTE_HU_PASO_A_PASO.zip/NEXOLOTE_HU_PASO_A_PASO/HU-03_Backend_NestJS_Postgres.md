# HU-03: Configuración Backend NestJS + PostgreSQL con pg (sin ORM)

## Objetivo
Inicializar backend NestJS, configurar módulo Database con pool pg, Swagger, validación y estructura modular.

## Alcance
BACKEND únicamente.

## Arquitectura
- Módulos por entidad
- DatabaseService con consultas SQL directas
- DTOs + class-validator
- Swagger en /api

## Pasos

### 1. Inicializar NestJS en apps/api
`ash
cd apps/api
nest new . --package-manager npm
`

### 2. Instalar dependencias
`ash
npm i pg
npm i @types/pg --save-dev
npm i @nestjs/swagger swagger-ui-express
npm i class-validator class-transformer
npm i dotenv
`

### 3. Crear módulo Database
Estructura:
`	ext
src/database/
├── database.module.ts
├── database.service.ts
└── database.providers.ts
`

### 4. Configurar variables de entorno
Crear apps/api/.env (NO subir a Git):
`env
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=tu_password
DB_NAME=nexolote
PORT=3000
NODE_ENV=development
`
Crear apps/api/.env.example con mismas claves sin valores.

### 5. Configurar main.ts
- Habilitar ValidationPipe global con whitelist y transform
- Configurar Swagger con DocumentBuilder
- Habilitar CORS para http://localhost:5173

## Comandos para ejecutar
`ash
cd apps/api
npm run start:dev
# http://localhost:3000
# http://localhost:3000/api
`

## Entregables
- apps/api inicializado
- src/database/ funcional con pool pg
- Swagger configurado
- .env.example creado

## Criterios de aceptación
- [ ] Conexión a PostgreSQL exitosa
- [ ] Swagger visible
- [ ] Validación global activa
