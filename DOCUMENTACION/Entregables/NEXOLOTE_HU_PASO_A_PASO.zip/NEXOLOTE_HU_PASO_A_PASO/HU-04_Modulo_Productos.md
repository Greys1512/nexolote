# HU-04: Módulo Productos (CRUD) - Frontend + Backend

## Objetivo
Implementar CRUD completo para Producto con arquitectura por capas.

## Alcance
FRONTEND + BACKEND

## Arquitectura
### Backend
- Módulo productos (module/controller/service)
- DatabaseService + SQL parametrizado
- DTOs + class-validator
- Swagger

### Frontend
- Componentes, páginas, servicios, tipos
- Axios
- React Router DOM

## PASO A PASO
### A. BACKEND (apps/api/src/productos)
`ash
cd apps/api
nest g module productos
nest g controller productos
nest g service productos
`
- Crear dto/create-producto.dto.ts y dto/update-producto.dto.ts
- Implementar service con consultas SQL parametrizadas
- Implementar controller con decoradores Swagger

### B. FRONTEND (apps/web/src)
- src/types/producto.types.ts
- src/services/productos.service.ts
- src/pages/Productos/ProductosList.tsx
- src/pages/Productos/ProductoForm.tsx
- src/pages/Productos/index.tsx
- Agregar ruta /productos

## ENDPOINTS
| Metodo | Ruta | Descripcion |
| --- | --- | --- |
| GET | /productos | Listar |
| GET | /productos/:id | Obtener |
| POST | /productos | Crear |
| PUT | /productos/:id | Actualizar |
| DELETE | /productos/:id | Eliminar |

## Comandos
`ash
cd apps/api && npm run start:dev
cd apps/web && npm run dev
`

## Entregables
- apps/api/src/productos/*
- apps/web/src/pages/Productos/*, services/productos.service.ts, types/producto.types.ts

## Criterios de aceptacion
- [ ] CRUD funcional backend
- [ ] CRUD funcional frontend
- [ ] Validaciones y Swagger
