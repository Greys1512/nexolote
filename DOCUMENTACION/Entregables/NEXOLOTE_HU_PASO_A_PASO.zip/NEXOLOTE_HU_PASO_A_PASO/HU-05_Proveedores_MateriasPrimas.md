# HU-05: Módulos Proveedores y Materias Primas - Frontend + Backend

## Objetivo
Implementar CRUD para Proveedor y MateriaPrima.

## Alcance
FRONTEND + BACKEND

## Arquitectura
### Backend
Módulos separados: proveedores, materias-primas. Misma estructura module/controller/service + DTOs + SQL directo.

### Frontend
Páginas, servicios y tipos por módulo.

## PASO A PASO

### A. BACKEND
`ash
cd apps/api
nest g module proveedores && nest g controller proveedores && nest g service proveedores
nest g module materias-primas && nest g controller materias-primas && nest g service materias-primas
`
Crear DTOs, implementar service con DatabaseService, controller con Swagger.

### B. FRONTEND
- src/types/proveedor.types.ts, src/types/materia-prima.types.ts
- src/services/proveedores.service.ts, src/services/materias-primas.service.ts
- src/pages/Proveedores/*, src/pages/MateriasPrimas/*
- Agregar rutas /proveedores, /materias-primas

## ENDPOINTS
Proveedores: GET/POST/PUT/DELETE /proveedores
Materias Primas: GET/POST/PUT/DELETE /materias-primas

## Entregables
- apps/api/src/proveedores/*, apps/api/src/materias-primas/*
- apps/web/src/pages/Proveedores/*, pages/MateriasPrimas/*, services correspondientes

## Criterios de aceptación
- [ ] CRUDs backend funcionales
- [ ] CRUDs frontend integrados
- [ ] Validaciones activas
