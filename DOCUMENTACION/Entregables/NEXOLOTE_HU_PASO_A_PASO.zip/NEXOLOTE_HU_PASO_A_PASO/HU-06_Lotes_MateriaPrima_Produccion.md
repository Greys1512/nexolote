# HU-06: Lotes de Materia Prima y Lotes de Producción - Frontend + Backend

## Objetivo
Gestionar ingreso de lotes de materia prima y creación de lotes de producción con validación de relaciones.

## Alcance
FRONTEND + BACKEND

## Arquitectura
### Backend
Módulos lotes-materia-prima y lotes-produccion con validación de FK y unicidad.

### Frontend
Formularios con selects (proveedor, materia prima, producto, responsable)

## PASO A PASO

### A. BACKEND
`ash
cd apps/api
nest g module lotes-materia-prima && nest g controller lotes-materia-prima && nest g service lotes-materia-prima
nest g module lotes-produccion && nest g controller lotes-produccion && nest g service lotes-produccion
`
Validar existencia de FK, unicidad codigo_lote_mp/codigo_lote, cantidades > 0.

### B. FRONTEND
- src/types/lote-materia-prima.types.ts, src/types/lote-produccion.types.ts
- src/services/lotes-materia-prima.service.ts, src/services/lotes-produccion.service.ts
- src/pages/Lotes/LotesMateriaPrima/*, src/pages/Lotes/LotesProduccion/*
- Rutas /lotes/materia-prima, /lotes/produccion

## ENDPOINTS
/lotes-materia-prima (CRUD)
/lotes-produccion (CRUD)

## Entregables
- apps/api/src/lotes-materia-prima/*, apps/api/src/lotes-produccion/*
- apps/web/src/pages/Lotes/* y servicios correspondientes

## Criterios de aceptación
- [ ] Validación de relaciones
- [ ] Códigos únicos
- [ ] Integración frontend funcional
