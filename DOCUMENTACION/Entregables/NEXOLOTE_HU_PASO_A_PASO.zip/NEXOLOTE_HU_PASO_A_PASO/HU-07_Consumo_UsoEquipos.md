# HU-07: Consumo de Materia Prima y Uso de Equipos (N:M) - Frontend + Backend

## Objetivo
Implementar tablas asociativas para trazabilidad entre lotes, materia prima y equipos.

## Alcance
FRONTEND + BACKEND

## Arquitectura
Tablas consumo_materia_prima y uso_equipo_lote con PK compuesta.

## PASO A PASO

### A. BACKEND
`ash
cd apps/api
nest g module consumo-materia-prima && nest g controller consumo-materia-prima && nest g service consumo-materia-prima
nest g module uso-equipo-lote && nest g controller uso-equipo-lote && nest g service uso-equipo-lote
`
Validar existencia de ambos registros, evitar duplicados, manejar PK compuesta.

### B. FRONTEND
- src/services/consumo-materia-prima.service.ts, src/services/uso-equipo-lote.service.ts
- src/pages/Trazabilidad/ConsumoMateriaPrima/*, src/pages/Trazabilidad/UsoEquipos/*
- Vistas para consultar trazabilidad por lote

## ENDPOINTS
/consumo-materia-prima (GET, POST, PUT, DELETE)
/uso-equipo-lote (GET, POST, PUT, DELETE)

## Entregables
- Módulos backend completos
- Vistas frontend de trazabilidad

## Criterios de aceptación
- [ ] PK compuesta gestionada correctamente
- [ ] Trazabilidad funcional (qué materias/equipos para un lote)
- [ ] Validaciones aplicadas
