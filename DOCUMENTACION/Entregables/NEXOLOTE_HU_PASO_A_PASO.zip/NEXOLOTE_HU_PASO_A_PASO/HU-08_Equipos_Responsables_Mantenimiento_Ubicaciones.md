# HU-08: Equipos, Responsables, Mantenimiento, Ubicaciones - Frontend + Backend

## Objetivo
Implementar catálogos base necesarios para trazabilidad.

## Alcance
FRONTEND + BACKEND

## Módulos
equipos, responsables, mantenimiento, ubicaciones

## PASO A PASO

### A. BACKEND
`ash
cd apps/api
nest g module equipos && nest g controller equipos && nest g service equipos
nest g module responsables && nest g controller responsables && nest g service responsables
nest g module mantenimiento && nest g controller mantenimiento && nest g service mantenimiento
nest g module ubicaciones && nest g controller ubicaciones && nest g service ubicaciones
`
Validar codigo_inventario único, FK a ubicacion/equipo/responsable.

### B. FRONTEND
Crear páginas y servicios para cada módulo con tablas y formularios.

## ENDPOINTS
/equipos, /responsables, /mantenimiento, /ubicaciones (CRUD completo)

## Entregables
- Módulos backend
- CRUDs frontend integrados

## Criterios de aceptación
- [ ] Catálogos funcionales
- [ ] Relaciones validadas
- [ ] Integración completa
