# HU-09: Movimientos de Lotes e Incidencias - Frontend + Backend

## Objetivo
Implementar seguimiento de movimientos entre ubicaciones/salida e incidencias por lote.

## Alcance
FRONTEND + BACKEND

## Reglas de negocio
- Ingreso inicial: id_ubicacion_origen puede ser null
- Salida: id_ubicacion_destino puede ser null
- Traslado: origen y destino requeridos
- Incidencia: id_responsable puede ser null

## PASO A PASO

### A. BACKEND
`ash
cd apps/api
nest g module movimientos-lote && nest g controller movimientos-lote && nest g service movimientos-lote
nest g module incidencias && nest g controller incidencias && nest g service incidencias
`
Aplicar validaciones condicionales, joins para mostrar nombres.

### B. FRONTEND
- src/services/movimientos-lote.service.ts, src/services/incidencias.service.ts
- src/pages/Movimientos/*, src/pages/Incidencias/*
- Formularios con lógica condicional según tipo_movimiento

## ENDPOINTS
/movimientos-lote, /incidencias (CRUD + filtros por lote)

## Entregables
- Módulos backend
- Vistas frontend con reglas aplicadas

## Criterios de aceptación
- [ ] Reglas de negocio implementadas
- [ ] Historial por lote funcional
- [ ] Integración correcta
