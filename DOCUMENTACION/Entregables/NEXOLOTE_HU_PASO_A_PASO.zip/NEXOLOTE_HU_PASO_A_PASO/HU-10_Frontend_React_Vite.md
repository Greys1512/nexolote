# HU-10: Frontend con React + TypeScript + Vite

## Objetivo
Inicializar frontend, configurar cliente API, rutas base y estructura.

## Alcance
FRONTEND únicamente (con configuración para consumir backend)

## Stack
React 18 + TypeScript + Vite + Axios + React Router DOM

## PASO A PASO

### 1. Inicializar proyecto en apps/web
`ash
cd apps/web
npm create vite@latest . -- --template react-ts
npm install
`

### 2. Instalar dependencias
`ash
npm install axios react-router-dom
npm install -D @types/node
`

### 3. Estructura de carpetas
Crear:
`	ext
src/components/{Layout,Table,Form,ui}
src/pages/{Dashboard,Productos,...}
src/services/
src/types/
src/routes/
src/utils/
src/hooks/
`

### 4. Configurar cliente API
Crear src/services/api.ts:
`	s
import axios from 'axios';
export const api = axios.create({
  baseURL: 'http://localhost:3000',
  headers: { 'Content-Type': 'application/json' }
});
`

### 5. Configurar rutas y App
Configurar React Router DOM con layout base.

## Comandos
`ash
cd apps/web
npm run dev
# http://localhost:5173
`

## Entregables
- apps/web inicializado
- Cliente API configurado
- Estructura base creada

## Criterios de aceptación
- [ ] Proyecto levanta sin errores
- [ ] Cliente API listo
- [ ] Estructura organizada
