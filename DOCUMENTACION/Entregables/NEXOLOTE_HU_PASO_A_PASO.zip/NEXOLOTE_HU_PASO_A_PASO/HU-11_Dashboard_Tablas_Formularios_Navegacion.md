# HU-11: Dashboard, Tablas, Formularios, Navegación - Frontend

## Objetivo
Desarrollar interfaz completa con dashboard, layout, tablas reutilizables, formularios y navegación.

## Alcance
FRONTEND

## Componentes clave
- Layout (Sidebar, Header, MainLayout)
- Table/DataTable reutilizable
- Form components
- Dashboard con cards/resumen

## PASO A PASO

### 1. Layout y navegación
Crear components/Layout con menú lateral con enlaces a todos los módulos.

### 2. Componentes reutilizables
src/components/Table/DataTable.tsx
src/components/Form/Input.tsx, Select.tsx, Button.tsx

### 3. Dashboard
src/pages/Dashboard/Dashboard.tsx - consumir endpoints para mostrar conteos/resumen

### 4. Integrar CRUDs
Conectar todas las páginas creadas en HU-04 a HU-09 con API

### 5. Validación y UX
Validación básica en formularios, mensajes de éxito/error

## Rutas a configurar
/, /productos, /proveedores, /materias-primas, /lotes/*, /equipos, /responsables, /mantenimiento, /ubicaciones, /movimientos, /incidencias, /trazabilidad/*

## Entregables
- Layout funcional
- Dashboard
- Tablas y formularios reutilizables
- Todos los CRUDs integrados

## Criterios de aceptación
- [ ] Navegación completa
- [ ] Dashboard funcional
- [ ] Integración frontend-backend completa
