﻿# HU-12: Swagger, Pruebas, Documentacion y Subida a Git - Frontend + Backend

## Objetivo
Completar documentacion Swagger, pruebas, README y subir proyecto a GitHub.

## Alcance
FRONTEND + BACKEND + DOCUMENTACION + GIT

## Pasos

### 1. Completar Swagger (Backend)
- Anadir @ApiProperty a DTOs
- Anadir @ApiTags, @ApiOperation, @ApiResponse a controladores
- Verificar en http://localhost:3000/api

### 2. Coleccion de pruebas
Crear docs/api/NEXOLOTE.postman_collection.json con todos los endpoints

### 3. Documentacion
Actualizar README.md raiz con stack, arquitectura monorepo, instalacion, variables de entorno, comandos para ejecutar backend/frontend, BD, Swagger

### 4. Validacion
Probar CRUDs, relaciones N:M, movimientos con reglas, incidencias

### 5. Subir a Git
`ash
git add .
git status
git commit -m "feat: NEXOLOTE completo - frontend React+Vite y backend NestJS+pg con trazabilidad"
git branch -M main
git remote add origin <URL_REPO_GITHUB>
git push -u origin main
`

## Entregables
- Swagger completo
- docs/api/* con coleccion Postman
- README.md actualizado
- Repositorio en GitHub

## Criterios de aceptacion
- [ ] Swagger funcional
- [ ] Pruebas basicas OK
- [ ] Documentacion completa
- [ ] Proyecto subido a Git correctamente
